

object EjNico {
  def main(args: Array[String]): Unit = {
    
    val lista = List("0,9 -> 5,9", "8,0 -> 0,8", "9,4 -> 3,4", "2,2 -> 2,1", "7,0 -> 7,4", "6,4 -> 2,0", "0,9 -> 2,9",
      "3,4 -> 1,4", "0,0 -> 8,8", "5,5 -> 8,2")

    //Apartado 1
    val mapa : Map[Double, Double] = lista
      .map(_.replace(",", "."))
      .map(s => (s.split("->")(0).trim.toDouble -> s.split("->")(1).trim.toDouble))
      .toMap
    println(mapa)

    //Apartado 2
    val media = mapa.keys.sum / mapa.size
    println(s"Mapa $mapa")
    println(s"Media $media")
    println(s"Cantidad de valores -> ${mapa.values.count(_ >= media)}")

    //Apartado 3
    var listaResultante: List[Float] = List()
    mapa.filter(v => v._2 > 2).map(v => listaResultante = listaResultante :+ v._1.toFloat + v._2.toFloat)
    println(s"Mapa $mapa")
    println(s"Lista resultante $listaResultante")

  }
}