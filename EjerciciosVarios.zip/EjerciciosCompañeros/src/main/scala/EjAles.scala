import scala.math.BigDecimal.double2bigDecimal
import scala.sys.SystemProperties.headless.{key, value}
import scala.util.control.Exception.noCatch.or

object EjAles {
  def main(args: Array[String]): Unit = {
    val cadena = "En un lugar de la Mancha, " +
      "de cuyo nombre no quiero acordarme, no ha" +
      " mucho tiempo que vivía un hidalgo de los de " +
      "lanza en astillero, adarga antigua, rocín flaco y" +
      " galgo corredor."

    //Apartado 1
    var numero = cadena.count(_ == 'a')
    println(numero)

    //Apartado 2
    numero = numero + 65
    println(numero)
    val letra = cadena.filter(_ >= numero)
    println(letra)

    //Apartado 3
    val rango = scala.util.Random.between(-10, 10)
    cadena.foreach(a => print(a.+(rango).toChar))
  }
}