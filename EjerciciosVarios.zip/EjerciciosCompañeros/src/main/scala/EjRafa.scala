import scala.sys.SystemProperties.headless.{key, value}

object EjRafa {
  def main(args: Array[String]): Unit = {
    val mapa = Map(
      1->3,
      2->5,
      3->2,
      4->7,
      5->4,
      6->9,
      7->3,
      8->4,
      9->8
    )

    //Apartado 1
    println(mapa.values.count(_>6))

    //Apartado 2
    var suma = 0
    mapa.keys.foreach(n => suma += n * mapa(n))
    println(suma)

    //Apartado3
    var mapaPar: Map[Int, Int] = Map()
    mapa.keys.foreach(n => if(mapa(n)%2==0) {mapaPar += n -> mapa(n)})
    println(mapaPar)
  }
}