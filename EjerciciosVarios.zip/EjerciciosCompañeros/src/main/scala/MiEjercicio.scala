import scala.collection.mutable

object MiEjercicio {

  def conversor(numero: Int): String = {
    var numEscrito = ""
    numero match {
      case 0 => numEscrito = "cero"
      case 1 => numEscrito = "uno"
      case 2 => numEscrito = "dos"
      case 3 => numEscrito = "tres"
      case 4 => numEscrito = "cuatro"
      case 5 => numEscrito = "cinco"
      case 6 => numEscrito = "seis"
      case 7 => numEscrito = "siete"
      case 8 => numEscrito = "ocho"
      case 9 => numEscrito = "nueve"
      case 10 => numEscrito = "diez"
      case 11 => numEscrito = "once"
      case _ => numEscrito = "error"
    }
    numEscrito
  }

  def main(args: Array[String]): Unit = {
    val set1: Set[Int] = Set(0,2,4,6,8,10)
    val set2: Set[Int] = Set(1,3,5,7,9,11)
    var lista: List[Int] = List()
    val mapa: mutable.Map[String, Int] = mutable.Map()

    //Apartado 1
    lista = set1.toList ++ set2.toList
    lista.sorted.foreach(v => {mapa += conversor(v) -> v})
    println(mapa)

    //Apartado 2
    mapa.keys.foreach(n => mapa += n -> n.length)
    println(mapa)
  }
}