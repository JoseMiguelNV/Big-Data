package sample

import com.google.gson.{Gson, JsonObject}
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession, functions}
import org.scalatest.funsuite.AnyFunSuite

import scala.io.{BufferedSource, Source}

class Test extends AnyFunSuite {

  val ss = SparkSession
    .builder()
    .appName("Test1")
    .config("spark.master", "local[*]")
    .getOrCreate()

  //---------------------------------------------------------------------------------------------------------------------------
  val gson = new Gson()
  val ficheroJson: BufferedSource = Source.fromFile("C:\\Users\\josem\\IdeaProjects\\Prueba_tetalco_JMNV\\json\\confFile.json")
  val cadenaFichero: String = ficheroJson.mkString
  val lecturaFichero: JsonObject = gson.fromJson(cadenaFichero, classOf[JsonObject])
  //---------------------------------------------------------------------------------------------------------------------------


  test("lecturaJson") {
    //Usar Asert para ver si es true o false ej -> (asert X = salida)
    println(lecturaFichero)
  }

  test("lecturadeFicheroDesdeJson") {
    val tipoFichero: String = lecturaFichero.get("input").getAsJsonObject.get("type").toString.replace("\"", "")
    if(tipoFichero.equals("csv")){
      val df: DataFrame = ss.read.csv(lecturaFichero.get("input").getAsJsonObject.get("path").toString.replace("\"", ""))
      println(df.head)
    }else{
      val df: DataFrame = ss.read.parquet(lecturaFichero.get("input").getAsJsonObject.get("path").toString.replace("\"", ""))
      println(df.head)
    }
  }

  test("addPrimaryKey"){
    val df: DataFrame = ss.read.csv(lecturaFichero.get("input").getAsJsonObject.get("path").toString.replace("\"", ""))
    var dfPrimaryKey = {
      Seq("Primary Key", identity())
    }
  }
}
