package sample

import com.google.gson.{Gson, JsonArray, JsonElement, JsonObject}
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, current_timestamp, date_add, dayofyear, hour, lit, monotonically_increasing_id, second}
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession, functions}
import scala.collection.mutable.ListBuffer
import scala.io.StdIn.readLine
import scala.io.{BufferedSource, Source}


object Principal extends App {
  Logger.getLogger("org").setLevel(Level.ERROR)
  val ss = SparkSession
    .builder()
    .appName("Prueba_Teralco_JMNV")
    .config("spark.master", "local[*]")
    .getOrCreate()

  val gson = new Gson()
  val Jsonfile: BufferedSource = Source.fromFile("C:\\Users\\josem\\IdeaProjects\\Prueba_tetalco_JMNV\\json\\confFile.json")
  val file: String = Jsonfile.mkString
  val readFile: JsonObject = gson.fromJson(file, classOf[JsonObject])
  var df: DataFrame = transformJsonToDataframe()

  //EJECUCIÓN DEL PROGRAMA
  println("Enter 'yes' for running he transformation process: ")
  if(readLine().equals("yes")){
    for(j <- 0 until readFile.get("transformations").getAsJsonArray.size()){
      getListOfTransformations(j) match {
        case "ADD_PRIMARY_KEY" => df = addPrimaryKey(df, getFieldName(j))
        case "ADD_CURRENT_DATE" => df = addIngestionDate(df, getFieldName(j))
        case "SUM_COLUMN" => df = addSumColumn(df, getFields(j), getFieldName(j))
        case "REST_COLUMN" => df = addRestColum(df, getFields(j), getFieldName(j))
        case "MULT_COLUMN" => df = addMultColumn(df, getFields(j), getFieldName(j))
        case "CONCAT_COLUMN" => df = addConcatColun(df, getFields(j), getFieldName(j))
        case "COUNT_ROWS" => df = addCountColumn(df, getFields(j), getFieldName(j))
        case "AVG_COLUMN" => df = addAvgColumn(df, getFields(j), getFieldName(j))
        case _ => println("Pass")
      }
    }
    //saveFile(df)
    df.show(5, false)
  }


  //CREACIÓN DEL DATAFRAME SEGÚN LOS PARÁMETROS DEL INPUT DEL JSON
  def transformJsonToDataframe(): DataFrame = {
    val csv = readFile.get("input").getAsJsonObject.get("type").getAsString
    var df: DataFrame = null
    if(csv == "csv"){
      df = ss.read.option("header", readFile.get("input").getAsJsonObject.get("withHeader").getAsString)
        .csv(readFile.get("input").getAsJsonObject.get("path").getAsString)
    }else{
      df = ss.read.option("header", readFile.get("input").getAsJsonObject.get("withHeader").getAsString)
        .parquet(readFile.get("input").getAsJsonObject.get("path").getAsString)
    }
    df
  }

  //ESCRITURA DEL FICHERO DE SALIDA SEGÚN LOS PARAMETROS DEL OUTPUT DEL JSON
  //LO HE DEJADO DE DOS FORMAS DISTINTAS PERO NO VA NINGUNA... HE PROBADO MUCHAS MAS, NO SE SI SERÁ TEMA DE VERSIONES.
  def saveFile(df: DataFrame): Unit = {
    val csv = readFile.get("output").getAsJsonObject.get("type").getAsString
    if(csv == "csv"){
      df.coalesce(1).write
        .option("type", readFile.get("output").getAsJsonObject.get("type").getAsString).option("path", readFile.get("output").getAsJsonObject.get("path").getAsString)
        .option("header", readFile.get("output").getAsJsonObject.get("withHeader").getAsString).option("delimiter", readFile.get("output").getAsJsonObject.get("delimiter").getAsString)
        .format("csv")
        .mode(SaveMode.Overwrite)
        .save()
    }else{
      df.coalesce(1).write
        .option("header", readFile.get("output").getAsJsonObject.get("withHeader").getAsString)
        .option("delimiter", readFile.get("output").getAsJsonObject.get("delimiter").getAsString)
        .parquet(readFile.get("output").getAsJsonObject.get("path").getAsString)
    }
  }

  //MÉTODO PARA ACCEDER AL ARRAY DE LAS TRASNFORMACIONES POR LA POSICIÓN
  def getListOfTransformations(positionList: Int): String = {
    readFile.get("transformations").getAsJsonArray.get(positionList).getAsJsonObject.get("transformation").getAsString
  }

  //MÉTODO PARA OBTENER UNA SECUENCIA DE LOS CAMPOS
  def getFields(positionList: Int): Seq[String] = {
    val listOfFields: ListBuffer[String] = ListBuffer[String]()
    val inputFields = readFile.get("transformations").getAsJsonArray.get(positionList).getAsJsonObject.get("inputFields")
    val agregationFields = readFile.get("transformations").getAsJsonArray.get(positionList).getAsJsonObject.get("aggregationFields")
    if (inputFields != null) {
      inputFields.getAsJsonArray.forEach(f => listOfFields.addOne(f.getAsString))
    } else if (agregationFields != null) {
      agregationFields.getAsJsonArray.forEach(f => listOfFields.addOne(f.getAsString))
    }
    listOfFields.toSeq
  }

  //MÉTODO PARA OBTENER LOS CAMPOS DE LAS TRANSFORMACIONES POR POSICIÓN
  def getFieldName(positionList: Int): String = {
    var name: String = null
    val inputName = readFile.get("transformations").getAsJsonArray.get(positionList).getAsJsonObject.get("field")
    if (inputName != null) {
      name = inputName.getAsString
    }
    name
  }

  //MÉTODO PARA AÑADIR EL CAMPO CLAVE PRIMARIA
  def addPrimaryKey(df: DataFrame, name: String): DataFrame = {
    val primaryKey: DataFrame = df.withColumn(name, monotonically_increasing_id() + 1) // row_number()
    primaryKey
  }

  //MÉETODO PARA AÑADIR EL CAMPO TIMESTAMP
  def addIngestionDate(df: DataFrame, name: String): DataFrame = {
    val ingestionDate: DataFrame = df.withColumn(name, current_timestamp())
    ingestionDate
  }

  //MÉTODO PARA AÑADIR EL CAMPO SUMA
  def addSumColumn(df: DataFrame, column: Seq[String], name: String): DataFrame = {
    val sumColumn: DataFrame = {
      df.withColumn(name, col(column(0)) + (col(column(1))))
    }
    sumColumn
  }

  //MÉTODO PARA AÑADIR EL CAMPO RESTA
  def addRestColum(df: DataFrame, column: Seq[String], name: String): DataFrame = {
    val restColumn: DataFrame = df.withColumn(name, col(column(0)).minus(col(column(1))))
    restColumn
  }

  //MÉTODO PARA AÑADIR EL CAMPO MULTIPLICACIÓN
  def addMultColumn(df: DataFrame, column: Seq[String], name: String): DataFrame = {
    val multColumn: DataFrame = df.withColumn(name, col(column(0)) * col(column(1)))
    multColumn
  }

  //MÉTODO PARA AÑADIR EL CAMPO CONCAT DELIMITER
  def addConcatColun(df: DataFrame, column: Seq[String], name: String): DataFrame = {
    val concatColumn: DataFrame = df.withColumn(name, functions.concat(column.map(col):_*))
    concatColumn
  }

  //MÉTODO PARA AÑADIR EL CAMPO COUNT_ROWS UTILIZANDO WINDOWS
  def addCountColumn(df: DataFrame, column: Seq[String], name: String): DataFrame = {
    val window = Window.partitionBy(column.map(col):_*)
    val countColumn = df
      .withColumn(name, functions.count("gf_gl_gross_balance_amount") over window)
      .orderBy(column.map(col):_*)
    countColumn
  }

  //MÉTODO PARA AÑADIR EL CAMPO AVG UTILIZANDO WINDOWS
  def addAvgColumn(df: DataFrame, column: Seq[String], name: String): DataFrame = {
    val window = Window.partitionBy(column.map(col):_*)
    val avgColumn = df
      .withColumn(name, functions.avg("gf_gl_gross_balance_amount") over window)
      .orderBy(column.map(col):_*)
    avgColumn
  }
}

